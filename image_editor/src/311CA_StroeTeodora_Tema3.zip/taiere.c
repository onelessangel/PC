// STROE TEODORA - 311CA

#include "anteturi.h"

int taiere(short int exista_fisier, short int *selectie, int *x1, int *y1,
		   int *x2, int *y2, unsigned char ***mat, int *linii, int *coloane,
		   unsigned char cifra)
{
	if (exista_fisier) {
		printf("Image cropped\n");

		unsigned char **copie_mat;
		int d_l = *x2 - *x1;
		int d_c = *y2 - *y1;
		int color;

		// se verifica daca imaginea este color sau nu
		if (cifra != '3' && cifra != '6')
			color = 0;
		else
			color = 1;

		if (!color) {
			// daca imaginea e gri/alb-negru
			copie_mat = aloc_matr_simpla(d_l + 1, d_c + 1);

			// se copiaza selectia intr-o matrice separata
			for (int i = 0; i <= d_l; i++)
				for (int j = 0; j <= d_c; j++)
					copie_mat[i][j] = (*mat)[*x1 + i][*y1 + j];

			// se elibereaza vechea matrice si se inlocuieste cu cea care
			// contine poza taiata
			elib_matr(mat, *linii);
			*mat = copie_mat;
			*linii = d_l + 1;
			*coloane = d_c + 1;

			copie_mat = NULL;
		} else {
			// daca imaginea e color
			copie_mat = aloc_matr_simpla(d_l + 1, (d_c + 1) * 3);

			// se copiaza selectia intr-o matrice separata
			for (int i = 0; i <= d_l; i++)
				for (int j = 0; j < (d_c + 1) * 3; j++)
					copie_mat[i][j] = (*mat)[*x1 + i][*y1 * 3 + j];

			// se elibereaza vechea matrice si se inlocuieste cu cea care
			// contine poza taiata
			elib_matr(mat, *linii);
			*mat = copie_mat;
			*linii = d_l + 1;
			*coloane = (d_c + 1) * 3;
		}

		// se reselecteaza intreaga suprafata
		reselectare(x1, y1, x2, y2, *linii, *coloane, selectie, color);
	} else {
		printf("No image loaded\n");
	}
	return 0;
}
