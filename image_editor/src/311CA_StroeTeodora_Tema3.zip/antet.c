// STROE TEODORA - 311CA

#include "anteturi.h"

void antet(FILE *text, unsigned char *cifra, int *coloane, int *linii,
		   short int *max_intensitate)
{
	unsigned char P;
	o_fi_comentariu_ascii(text);

	fscanf(text, "%c", &P);
	fscanf(text, "%c ", cifra);

	o_fi_comentariu_ascii(text);

	fscanf(text, "%d%d ", coloane, linii);

	o_fi_comentariu_ascii(text);

	if (*cifra != '1' && *cifra != '4') {
		fscanf(text, "%hd ", max_intensitate);

		o_fi_comentariu_ascii(text);
	}
}

void o_fi_comentariu_ascii(FILE *text)
{
	char comentariu[MAX_LUNG];
	unsigned char car_urm;

	fscanf(text, "%c", &car_urm);
	while (car_urm == '#') {
		fgets(comentariu, MAX_LUNG, text);
		fscanf(text, "%c", &car_urm);
	}
	fseek(text, -1, SEEK_CUR);
}
