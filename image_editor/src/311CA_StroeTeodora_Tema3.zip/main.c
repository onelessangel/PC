// STROE TEODORA - 311CA

#include "anteturi.h"

int main(void)
{
	char *comanda, copie[MAX_LUNG], input[MAX_LUNG];
	unsigned char cifra, **mat = NULL;
	int linii, coloane, x1, y1, x2, y2;
	short int exista_fisier = 0, max_intensitate, selectie = 0;
	// se citeste prima linie de input
	fgets(input, MAX_LUNG, stdin);
	input[strlen(input) - 1] = 0;
	// se face o copie a input-ului
	strcpy(copie, input);
	comanda = strtok(input, " ");
	while (comanda) {
		// EXIT - terminare
		if (strcmp(comanda, "EXIT") == 0) {
			*comanda = 0; comanda = NULL;
			terminare(exista_fisier, linii, &mat);
		} else {
			// LOAD - incarcare
			if (strcmp(comanda, "LOAD") == 0) {
				incarcare(copie, &cifra, &linii, &coloane, &max_intensitate,
						  &exista_fisier, &x1, &y1, &x2, &y2, &mat, &selectie);
			// SELECT & SELECT ALL - selectare
			} else if (strcmp(comanda, "SELECT") == 0) {
				selectare(exista_fisier, &selectie, copie, &x1, &y1, &x2, &y2,
						  linii, coloane, cifra);
			//ROTATE - rotire
			} else if (strcmp(comanda, "ROTATE") == 0) {
				rotire(exista_fisier, copie, &selectie, &x1, &y1, &x2, &y2,
					   &mat, &linii, &coloane, cifra);
			// CROP - taiere
			} else if (strcmp(comanda, "CROP") == 0) {
				taiere(exista_fisier, &selectie, &x1, &y1, &x2, &y2, &mat,
					   &linii, &coloane, cifra);
			// GRAYSCALE - printre_tonuri_cenusii
			} else if (strcmp(comanda, "GRAYSCALE") == 0) {
				printre_tonuri_cenusii(exista_fisier, cifra, &mat, x1, y1,
									   x2, y2);
			// SEPIA - sepia
			} else if (strcmp(comanda, "SEPIA") == 0) {
				sepia(exista_fisier, cifra, &mat, x1, y1, x2, y2,
					  max_intensitate);
			// SAVE - salvare
			} else if (strcmp(comanda, "SAVE") == 0) {
				salvare(exista_fisier, copie, mat, linii, coloane, cifra,
						max_intensitate);
			} else {
				printf("Invalid command\n");
			}
			// se citeste urmatoarea linie de input
			if (fgets(input, MAX_LUNG, stdin)) {
				if (input[strlen(input) - 1] == '\n') {
					input[strlen(input) - 1] = 0;
					// se face o copie a input-ului
					strcpy(copie, input); comanda = strtok(input, " ");
				}
			} else {
				*comanda = 0; comanda = NULL;
			}
		}
	}
	return 0;
}
