// STROE TEODORA - 311CA

#include "anteturi.h"

void terminare(short int exista_fisier, int linii, unsigned char ***mat)
{
	if (exista_fisier == 1) {
		// se elibereaza matricea
		if (*mat)
			elib_matr(mat, linii);
	} else {
		printf("No image loaded\n");
	}
}
