// STROE TEODORA - 311CA

#include "anteturi.h"

int rotire(short int exista_fisier, char input[MAX_LUNG], short int *selectie,
		   int *x1, int *y1, int *x2, int *y2, unsigned char ***mat,
		   int *linii, int *coloane, unsigned char cifra)
{
	if (exista_fisier) {
		int unghi = 0;
		short int semn;
		int color;
		char *rest;
		char cifre[] = "1234567890";

		rest = strtok(input, " ");
		rest = strtok(NULL, " ");
		if (!rest) {
			printf("Invalid command\n");
			return 0;
		}

		// se stabileste unghiul si semnul sau
		if (rest[0] == '-' && strspn(rest + 1, cifre) == strlen(rest + 1)) {
			semn = -1;
			unghi = atoi(rest + 1);
		} else {
			if (strspn(rest, cifre) == strlen(rest)) {
				semn = 1;
				unghi = atoi(rest);
			}
		}

		// se verifica daca unghiul este valid
		if (unghi % 90 != 0 || unghi > 360) {
			printf("Unsupported rotation angle\n");
			return 0;
		}
		// se verifica daca selectia este de forma patratica
		if (*selectie == 1) {
			if (*x2 - *x1 != *y2 - *y1) {
				printf("The selection must be square\n");
				return 0;
			}
		}
		if (semn == 1)
			printf("Rotated %d\n", unghi);
		else
			printf("Rotated -%d\n", unghi);
		if (unghi == 0 || unghi == 360)
			return 0;

		// se verifica daca imaginea este color sau nu
		if (cifra != '3' && cifra != '6')
			color = 0;
		else
			color = 1;

		int d_l = *x2 - *x1;
		int d_c = *y2 - *y1;

		// se realizeaza rotirea la unghiul specificat
		if ((unghi == 90 && semn == 1) || (unghi == 270 && semn == -1))
			r_90(color, mat, *selectie, d_c, d_l, *x1, *y1, linii, coloane);
		else if (unghi == 180)
			r_180(color, mat, *selectie, d_c, d_l, *x1, *y1, linii, coloane);
		else if ((unghi == 270 && semn == 1) || (unghi == 90 && semn == -1))
			r_270(color, mat, *selectie, d_c, d_l, *x1, *y1, linii, coloane);

		// daca s-a lucrat cu toata poza, se reselecteaza intreaga suprafata
		if (*selectie == 0)
			reselectare(x1, y1, x2, y2, *linii, *coloane, selectie, color);
	} else {
		printf("No image loaded\n");
	}
	return 0;
}
