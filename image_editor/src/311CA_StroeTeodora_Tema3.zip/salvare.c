// STROE TEODORA - 311CA

#include "anteturi.h"

int salvare(unsigned char exista_fisier, char input[MAX_LUNG],
			unsigned char **mat, int linii, int coloane, unsigned char cifra,
			short int max_intensitate)
{
	if (exista_fisier) {
		FILE *fisier;
		// matrice in care sunt retinute posibilele valori pentru
		// noul tip de imagine, in functie de formatul fisierului
		// si tipul imaginii actuale
		char transformare[2][7] = {{'0', '4', '5', '6', '4', '5', '6'},
								   {'0', '1', '2', '3', '1', '2', '3'}};
		char *format, *nume_fisier;
		int ascii = 0;

		nume_fisier = strtok(input, " ");
		// se citeste numele fisierului
		nume_fisier = strtok(NULL, " ");
		if (!nume_fisier) {
			printf("Invalid command\n");
			return 0;
		}

		// se determina formatul de salvare
		format = strtok(NULL, " ");
		if (!format)
			ascii = 0;
		else
			if (strcmp(format, "ascii") == 0)
				ascii = 1;

		printf("Saved %s\n", nume_fisier);

		// se deschide in mod text fisierul si se scrie antetul imaginii
		fisier = fopen(nume_fisier, "w+");
		fprintf(fisier, "P%c\n", transformare[(int)ascii][(int)cifra - '0']);

		if (cifra == '3' || cifra == '6')
			fprintf(fisier, "%d %d\n", coloane / 3, linii);
		else
			fprintf(fisier, "%d %d\n", coloane, linii);
		if (cifra != '1' && cifra != '4')
			fprintf(fisier, "%hd\n", max_intensitate);

		// se salveaza in formatul cerut matricea
		if (ascii == 1) {
			salvare_matr(mat, coloane, linii, fisier, ascii);
			fclose(fisier);
		} else {
			fclose(fisier);
			fisier = fopen(nume_fisier, "ab");
			salvare_matr(mat, coloane, linii, fisier, ascii);
			fclose(fisier);
		}
	} else {
		printf("No image loaded\n");
	}
	return 0;
}

void salvare_matr(unsigned char **mat, int coloane, int linii, FILE *fisier,
				  int ascii)
{
	if (ascii == 1) {
		// salvarea matricei in format ascii
		for (int i = 0; i < linii; i++) {
			for (int j = 0; j < coloane; j++)
				fprintf(fisier, "%hd ", mat[i][j]);
			fprintf(fisier, "\n");
		}
	} else {
		// salvarea matricei in format binar
		for (int i = 0; i < linii; i++)
			for (int j = 0; j < coloane; j++)
				fwrite(&mat[i][j], sizeof(unsigned char), 1, fisier);
	}
}
